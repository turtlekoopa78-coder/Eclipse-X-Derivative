#!/usr/bin/env python3
"""Build the Eclipse x Derivative pack: python3 apply_fusion.py Eclipse-Shader-Unstable.zip [output.zip]
Takes the Eclipse Unstable zip from GitHub (https://github.com/Merlin1809/Eclipse-Shader/archive/refs/heads/Unstable.zip),
replaces the modified files with the ones next to this script, and writes a ready-to-use shaderpack zip."""
import sys, os, zipfile
src = sys.argv[1]; out = sys.argv[2] if len(sys.argv) > 2 else "Eclipse-Derivative-Fusion.zip"
here = os.path.dirname(os.path.abspath(__file__))
over = {}
for dp, _, fn in os.walk(here):
    for f in fn:
        p = os.path.join(dp, f); rel = os.path.relpath(p, here).replace(os.sep, "/")
        if rel != "apply_fusion.py": over[rel] = p
with zipfile.ZipFile(src) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
    names = zin.namelist(); root = names[0].split("/")[0] + "/"          # GitHub zips have one top-level folder
    seen = set()
    for n in names:
        rel = n[len(root):]
        if not rel or rel.startswith((".git", ".github")) or n.endswith("/"): continue
        if rel in over: zout.write(over[rel], rel); seen.add(rel)
        else: zout.writestr(rel, zin.read(n))
    for rel, p in over.items():
        if rel not in seen: zout.write(p, rel)
print("wrote", out, "(", len(over), "files replaced/added )")
