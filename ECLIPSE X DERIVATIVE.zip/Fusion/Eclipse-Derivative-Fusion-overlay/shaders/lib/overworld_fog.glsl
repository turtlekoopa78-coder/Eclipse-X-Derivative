uniform float noPuddleAreas;

float densityAtPosFog(in vec3 pos){
	pos /= 18.;
	pos.xz *= 0.5;
	vec3 p = floor(pos);
	vec3 f = fract(pos);
	f = (f*f) * (3.-2.*f);
	vec2 uv =  p.xz + f.xz + p.y * vec2(0.0,193.0);
	vec2 coord =  uv / 512.0;
	vec2 xy = texture(noisetex, coord).yx;
	return mix(xy.r,xy.g, f.y);
}


//--------------------------------------------------------------------------------------------------
// Helpers shared by Derivative's fog and volumetric light (always compiled, any fog style)
//--------------------------------------------------------------------------------------------------

// Derivative's TIME_FADE curve: peaks at dawn/dusk (sun ~10 degrees up), strong at night, nearly absent
// at noon, and always allowed to come back with rain.
float derivTimeFadeRaw(){
	float sunY = cos((float(worldTime % 24000) - 6000.0) * (6.2831853 / 24000.0)); // 1 noon .. -1 midnight
	float meFade = sunY < 0.18 ? 0.37 + 1.2 * max(0.0, -sunY) : 1.7;
	float meWeight = pow(clamp(1.0 - meFade * abs(sunY - 0.18), 0.0, 1.0), 2.0);
	float midnight = sunY < 0.0 ? 1.0 - meWeight : 0.0;
	return clamp(max(pow(meWeight + 0.05, 2.0) + midnight * 2.0, rainStrength), 0.0, 3.0);
}

float derivHG(in float cosTheta, in float g){
	float gg = g * g;
	float phase = 1.0 + gg - 2.0 * g * cosTheta;
	return (1.0 - gg) / (12.5663706 * phase * sqrt(phase));
}

float derivRayleigh(in float cosTheta){
	const float c = 3.0 / 16.0 * 0.3183099;
	return cosTheta * cosTheta * c + c;
}

#if FOG_STYLE == 1
//--------------------------------------------------------------------------------------------------
// Fog model ported from Derivative (HaringPro): density types, phase functions, sun-march.
// The 3D noise is routed through Eclipse's own noise lookup (densityAtPosFog), so no extra
// textures are required. All functions are prefixed "deriv" to avoid clashes.
//--------------------------------------------------------------------------------------------------

// smooth 3D value noise in [0,1], one noise cell per world unit (Derivative's Get3DNoiseSmooth)
float derivNoise3D(in vec3 p){
	return densityAtPosFog(p * vec3(36.0, 18.0, 36.0));
}

// Fog thickness fade (Derivative's TIME_FADE); optional.
float derivTimeFade(){
	#ifdef DERIV_FOG_TIME_FADE
		return derivTimeFadeRaw();
	#else
		return 1.0;
	#endif
}

// Derivative's CalculateFogDensity(): dimensionless shape, later scaled by DERIV_FOG_DENSITY.
float derivFogDensity(in vec3 p){
	float windTime = frameTimeCounter * 0.01 * DERIV_FOG_WIND;
	vec3 wind = vec3(windTime, 0.0, windTime * 0.6);

	#if DERIV_FOG_TYPE == 0
		// Low: flat height mist
		float fogDensity = exp2(min((SEA_LEVEL + 32.0 - p.y) * (1.0 / 12.0), 0.2));
		return fogDensity * 0.5;
	#elif DERIV_FOG_TYPE == 1
		// Medium: noisy height fog
		float fogDensity = exp2(min((SEA_LEVEL + 28.0 - p.y) * 0.15, 0.2));

		p *= 0.06;
		p += wind;
		float noise = derivNoise3D(p) * 4.0;
		noise -= derivNoise3D(p * 4.0 + wind);

		return clamp(noise * 4.0 * fogDensity - 5.0, 0.0, 1.0) * 1.4;
	#elif DERIV_FOG_TYPE == 2
		// High: 4 octaves, layered around sea level
		float falloff = exp(-abs(p.y - SEA_LEVEL) * 0.01);

		p *= 0.04;
		p += wind;
		float noise = derivNoise3D(p) * 0.5;
		p += wind;
		noise += derivNoise3D(p * 3.2) * 0.25;
		p += wind;
		noise += derivNoise3D(p * 9.6) * 0.125;
		p += wind;
		noise += derivNoise3D(p * 28.8) * 0.0625;

		return clamp(noise * 12.0 * falloff - 4.5, 0.0, 1.0) * 9.0;
	#else
		// Ultra: 5 octaves, thick clumpy ground fog
		float falloff = exp2(-abs(p.y - SEA_LEVEL) * 0.01);
		p += wind;
		p *= 0.013;
		float weight = 0.5;
		float noise = 0.0;

		for (int i = 0; i < 5; i++, weight *= 0.5) {
			noise += weight * derivNoise3D(p);
			p = (p + wind) * 4.0;
		}

		return clamp(falloff * noise * 4e2 - 1.7e2, 0.0, 1.0) * 48.0;
	#endif
}

float derivCornetteShanks(in float cosTheta, in float g){
	float gg = g * g;
	float a = (1.0 - gg) / (2.0 + gg) * 3.0 * 0.3183099;
	float b = (1.0 + cosTheta * cosTheta) * pow(1.0 + gg - 2.0 * g * cosTheta, -1.5);
	return a * b * 0.125;
}

// the four multiple-scattering octaves of Derivative's High/Ultra fog (computed once per ray)
vec4 derivPhases(in float LdotV){
	return vec4(
		(derivHG(LdotV, 0.6)          + derivHG(LdotV, -0.3))          * 0.5,
		(derivHG(LdotV * 0.5, 0.6)    + derivHG(LdotV * 0.5, -0.3))    * 0.25,
		(derivHG(LdotV * 0.25, 0.6)   + derivHG(LdotV * 0.25, -0.3))   * 0.125,
		(derivHG(LdotV * 0.125, 0.6)  + derivHG(LdotV * 0.125, -0.3))  * 0.0625
	);
}

// How strongly the fog at `pos` scatters light arriving along `lightDir` (replaces fogPhase()*5.0).
float derivSunScatter(in vec3 pos, in vec3 lightDir, in vec4 phases, in float LdotV, in float timeFade){
	#if DERIV_FOG_TYPE > 1
		float LdotV01 = LdotV * 0.5 + 0.5;

		// march 4 growing steps towards the light: optical depth of the fog between here and the sun
		float stepSize = 5.0;
		float sunlightOD = 0.0;
		vec3 checkPos = pos;
		for (int i = 0; i < 4; i++, checkPos += lightDir * stepSize) {
			float dens = derivFogDensity(checkPos);
			if (dens < 1e-5) continue;
			sunlightOD += dens * stepSize;
			stepSize *= 1.5;
		}
		sunlightOD *= DERIV_FOG_DENSITY * timeFade;

		// powder effect + four octaves of multiple scattering
		float scattering = (1.0 - exp(-sunlightOD * 2.0)) * (1.0 - LdotV01) + LdotV01;
		scattering *= exp(-sunlightOD * 2.4) * phases.x
					+ exp(-sunlightOD * 1.2) * phases.y
					+ exp(-sunlightOD * 0.6) * phases.z
					+ exp(-sunlightOD * 0.3) * phases.w;

		return scattering * float(DERIV_FOG_TYPE * DERIV_FOG_TYPE) * DERIV_FOG_SCATTERING;
	#else
		// Low / Medium: Derivative's single Cornette-Shanks + back-scatter phase
		float phase = derivCornetteShanks(LdotV, 0.7 - rainStrength * 0.3) * 0.45 + derivHG(LdotV, -0.3) * 0.15 + 0.1;
		return phase * 3.0 * DERIV_FOG_SCATTERING;
	#endif
}
#endif // FOG_STYLE == 1


float cloudVol(in vec3 pos, float maxDistance){
	
	float fogYstart = FOG_START_HEIGHT + 3.0;
	vec3 samplePos = pos*vec3(1.0,1./24.,1.0);
	vec3 samplePos2 = pos*vec3(1.0,1./48.,1.0);
	
	float uniformFog = 0.0;

	float low_gradientFog = exp2(-0.15 * max(pos.y - fogYstart,0.0));
	float medium_gradientFog = exp2(-0.06 * max(pos.y - fogYstart,0.0));
	float high_gradientFog = exp2(-0.001 * max(pos.y - fogYstart,0.0));
	
	float fog_shape = 0.0;
	float fog_erosion = 0.0;
	if(sandStorm < 1.0 && snowStorm < 1.0){
		fog_shape = 1.0 - densityAtPosFog(samplePos * 24.0);
		fog_erosion = 1.0 - densityAtPosFog(samplePos2 * 200.0 - vec3(min(max(fog_shape - 0.6 ,0.0) * 2.0 ,1.0)*200.0));
	}
	
	float cloudyFog = max(min(max(fog_shape - 0.6 ,0.0) * 2.0 ,1.0) - fog_erosion * 0.4	, 0.0)	*	exp(-0.05 * max(pos.y - (fogYstart+20),0.0));
	float rainyFog = (high_gradientFog * 0.0085 + medium_gradientFog) * rainStrength * noPuddleAreas * (1.0 + thunderStrength) * RainFog_amount;

	#ifdef PER_BIOME_ENVIRONMENT
		rainyFog += high_gradientFog * isPaleGarden * PALE_GARDEN_UNIFORM_DENSITY;
	#endif
	
	if(sandStorm > 0.0 || snowStorm > 0.0){
		float IntenseFogs = pow(1.0 - densityAtPosFog( (samplePos2  - vec3(frameTimeCounter,0,frameTimeCounter)*15.0) * 100.0),2.0) * mix(1.0, medium_gradientFog, snowStorm);
		cloudyFog = mix(cloudyFog, IntenseFogs, sandStorm+snowStorm);

		low_gradientFog = mix(low_gradientFog, 1.0, sandStorm+snowStorm);
	}

	#if FOG_STYLE == 1
		// Derivative fog everywhere, except where Eclipse's own biome fog / sand+snow storms take over.
		float derivWeight = clamp(1.0 - maxDistance - sandStorm - snowStorm, 0.0, 1.0);

		float derivFog = 0.0;
		if (derivWeight > 0.0) {
			// x8: Eclipse's fog loop integrates density / 8 per block
			derivFog = derivFogDensity(pos) * DERIV_FOG_DENSITY * 8.0 * derivTimeFade() * derivWeight;
		}

		if (derivWeight < 1.0) {
			FogDensities(low_gradientFog, cloudyFog, maxDistance, SC_fog.x, SC_fog.y);
			low_gradientFog *= 1.0 - derivWeight;
			cloudyFog *= 1.0 - derivWeight;
		} else {
			low_gradientFog = 0.0;
			cloudyFog = 0.0;
		}

		return uniformFog + low_gradientFog + cloudyFog + rainyFog + derivFog;
	#else
		FogDensities(low_gradientFog, cloudyFog, maxDistance, SC_fog.x, SC_fog.y);

		return uniformFog + low_gradientFog + cloudyFog + rainyFog;
	#endif
}

float phaseRayleigh(float cosTheta) {
	const float oneOverPi 	= 1.0 / acos(-1.0);
	const vec2 mul_add = vec2(0.1, 0.28) * oneOverPi;
	return cosTheta * mul_add.x + mul_add.y; // optimized version from [Elek09], divided by 4 pi for energy conservation
}
float fogPhase(float lightPoint){
	float linear = clamp(-lightPoint*0.5+0.5,0.001,1.0);
	float linear2 = 1.0 - clamp(lightPoint,0.0,1.0);

	float exponential = exp2(pow(linear,0.3) * -15.0 ) * 1.5;
	exponential += sqrt(exp2(sqrt(linear) * -12.5));

	// float exponential = 1.0 / (linear * 10.0 + 0.05);

	return exponential;
}

uniform ivec2 eyeBrightness;

vec4 GetVolumetricFog(
	in vec3 viewPosition,
	in vec3 sunVector,
	in vec2 dither,
	in vec3 LightColor,
	in vec3 AmbientColor,
	in vec3 AveragedAmbientColor,
	in float cloudPlaneDistance
){
	#ifndef TOGGLE_VL_FOG
		return vec4(0.0,0.0,0.0,1.0);
	#endif
	
	int SAMPLECOUNT = VL_SAMPLES;

	//project pixel position into projected shadowmap space
	vec3 dVWorld = mat3(gbufferModelViewInverse) * viewPosition;
	vec3 playerPos = dVWorld + gbufferModelViewInverse[3].xyz;
	// vec3 rayStartPos = playerPos - gbufferModelViewInverse[3].xyz;
	#ifdef CUSTOM_MOON_ROTATION
		vec3 fragposition = mat3(customShadowMatrixSSBO) * playerPos  + customShadowMatrixSSBO[3].xyz;
	#else
		vec3 fragposition = mat3(shadowModelView) * playerPos + shadowModelView[3].xyz;
	#endif
	fragposition = diagonal3(shadowProjection) * fragposition + shadowProjection[3].xyz;

	//project view origin into projected shadowmap space
	vec3 start = toShadowSpaceProjected(vec3(0.0));

	//rayvector into projected shadow map space
	//we can use a projected vector because its orthographic projection
	//however we still have to send it to curved shadow map space every step
	vec3 dV = fragposition - start;

	vec3 rayDir = normalize(playerPos);

	float rayLength = length(dVWorld);

	#if defined DISTANT_HORIZONS || defined VOXY
		float maxLength = min(min(rayLength, cloudPlaneDistance), max(far, dhVoxyRenderDistance))/rayLength;
		// float maxLength = min(length(dVWorld), max(far, dhVoxyRenderDistance))/length(dVWorld);
	#else
		float maxLength = min(min(rayLength, cloudPlaneDistance), far)/rayLength;
	#endif
	
	dV *= maxLength;
	dVWorld *= maxLength;

	float dL = length(dVWorld)/8.0;

	const float expFactor = 11.0;

	/// -------------  COLOR/LIGHTING STUFF ------------- \\\
	
	vec3 color = vec3(0.0);
	vec3 finalAbsorbance = vec3(1.0);

	float totalAbsorbance = 1.0;

	// float fogAbsorbance = 1.0;
	// float atmosphereAbsorbance = 1.0;
	vec3 atmosphereAbsorbance = vec3(1.0);

	float SdotV = dot(sunVector, rayDir);

	///// ----- fog lighting
	//Mie phase + somewhat simulates multiple scattering (Horizon zero down cloud approx)
	float sunPhase = fogPhase(SdotV)*5.0;
	float skyPhase = 0.5 + pow(1.0-pow(1.0-clamp(rayDir.y*0.5+0.5,0.0,1.0),2.0),5.0)*2.0;
	float rayL = phaseRayleigh(SdotV);

	vec3 rC = vec3(sky_coefficientRayleighR*1e-6, sky_coefficientRayleighG*1e-5, sky_coefficientRayleighB*1e-5) ;
	vec3 mC = vec3(fog_coefficientMieR*1e-6, fog_coefficientMieG*1e-6, fog_coefficientMieB*1e-6);
	
	#if defined EXCLUDE_WRITE_TO_LUT && defined USE_CUSTOM_FOG_LIGHTING_COLORS
		LightColor = dot(LightColor,vec3(0.21, 0.72, 0.07)) * vec3(DIRECTLIGHT_FOG_R,DIRECTLIGHT_FOG_G,DIRECTLIGHT_FOG_B);
		AmbientColor = dot(AmbientColor,vec3(0.21, 0.72, 0.07)) * vec3(INDIRECTLIGHT_FOG_R,INDIRECTLIGHT_FOG_G,INDIRECTLIGHT_FOG_B);
	#endif

	vec3 skyLightPhased = AmbientColor;
	vec3 LightSourcePhased = LightColor;

	skyLightPhased *= skyPhase;
	LightSourcePhased *= sunPhase;

	#ifdef AMBIENT_LIGHT_ONLY
		LightSourcePhased = vec3(0.0);
	#endif

	#ifdef PER_BIOME_ENVIRONMENT
		vec3 biomeDirect = LightSourcePhased; 
		vec3 biomeIndirect = skyLightPhased;
		float inBiome = BiomeVLFogColors(biomeDirect, biomeIndirect);
	#endif

	float inACave = 1.0 - caveDetection;
	float lightLevelZero = pow(clamp(eyeBrightnessSmooth.y/240.0 ,0.0,1.0),3.0);

	#ifdef DERIV_VOLUMETRIC_LIGHT
		// Derivative's volumetric light: clear-air density with a Rayleigh phase (x8: Eclipse's loop integrates density / 8 per block)
		#ifdef DERIV_VOLUMETRIC_LIGHT_TIME_FADE
			float derivAirFade = derivTimeFadeRaw();
		#else
			float derivAirFade = 1.0;
		#endif
		float derivAir = 8.0 * DERIV_VOLUMETRIC_LIGHT_STRENGTH * derivRayleigh(SdotV) * (4.0 / far) * derivAirFade;
	#else
		float derivAir = 0.0;
	#endif

	#if FOG_STYLE == 1
		// Derivative fog: per-ray constants (time fade, scattering octaves)
		float derivFade = derivTimeFade();
		vec4 derivPhase = derivPhases(SdotV);
	#endif

	// SkyLightColor *= lightLevelZero*0.9 + 0.1;
	// vec3 finalsceneColor = vec3(0.0);


	for (int i = 0; i < SAMPLECOUNT; i++) {
		float d = (pow(expFactor, float(i+dither.x)/float(SAMPLECOUNT))/expFactor - 1.0/expFactor)/(1-1.0/expFactor);
		float dd = pow(expFactor, float(i+dither.y)/float(SAMPLECOUNT)) * log(expFactor) / float(SAMPLECOUNT)/(expFactor-1.0);

		// #ifdef VOLUMETRIC_CLOUDS
		// 	// check if the fog intersects clouds
		// 	if(length(d*dVWorld) > cloudPlaneDistance) break;
		// #endif

		vec3 progress = start.xyz + d*dV;
		vec3 progressP = gbufferModelViewInverse[3].xyz + d*dVWorld;
		vec3 progressW = progressP + cameraPosition;

		//------------------------------------
		//------ SAMPLE SHADOWS FOR FOG EFFECTS
		//------------------------------------
			#if defined DISTORT_SHADOWMAP
				float distortFactor = calcDistort(progress.xy);
			#else
				float distortFactor = 1.0;
			#endif
			vec3 shadowPos = vec3(progress.xy*distortFactor, progress.z);

			vec3 sh = vec3(1.0);
			if (abs(shadowPos.x) < 1.0-0.5/2048. && abs(shadowPos.y) < 1.0-0.5/2048.){
				shadowPos = shadowPos*vec3(0.5,0.5,0.5/6.0)+0.5;
				if (shadowPos.z < 1.0 && shadowPos.z > 0.0) {
					#ifdef TRANSLUCENT_COLORED_SHADOWS
						sh = vec3(texture(shadowtex0HW, shadowPos).x);

						if(texture(shadowtex1HW, shadowPos).x > shadowPos.z && sh.x < 1.0){
							vec4 translucentShadow = texture(shadowcolor0, shadowPos.xy);
							if(translucentShadow.a < 0.9) sh = normalize(translucentShadow.rgb+0.0001);
						}
					#else
						sh = vec3(texture(shadowtex0HW, shadowPos).x);
					#endif
				}
			}

			sh *= GetCloudShadow(progressW, sunVector);


		#ifdef PER_BIOME_ENVIRONMENT
			float maxDistance = inBiome * min(max(1.0 -  length(d*dVWorld.xz)/(32*8),0.0)*2.0,1.0);
			float fogDensity = cloudVol(progressW, maxDistance) * inACave;
		#else
			float fogDensity = cloudVol(progressW, 0.0) * inACave;
		#endif

		//------------------------------------
		//------ MAIN FOG EFFECT
		//------------------------------------
			#if defined TRANSLUCENT_COLORED_SHADOWS && !defined DERIV_RAY_STAINED_GLASS_TINT
				// Derivative's default: light shafts are not tinted by stained glass
				sh = vec3(max(sh.r, max(sh.g, sh.b)));
			#endif

			#if FOG_STYLE == 1
				// clear-air light shafts, then Derivative's sun-marched multi-lobe scattering
				fogDensity += derivAir * inACave;

				float derivScatter = 0.0;
				if (fogDensity > 1e-5) derivScatter = derivSunScatter(progressW, sunVector, derivPhase, SdotV, derivFade);

				vec3 stepLightSource = LightColor * derivScatter;
				#ifdef AMBIENT_LIGHT_ONLY
					stepLightSource = vec3(0.0);
				#endif
			#else
				#ifdef DERIV_VOLUMETRIC_LIGHT
					fogDensity += derivAir * inACave; // light shafts also work with Eclipse's own fog
				#endif
				vec3 stepLightSource = LightSourcePhased;
			#endif

			float fogVolumeCoeff = exp(-fogDensity*dd*dL); // this is like beer-lambert law or something

			#ifdef PER_BIOME_ENVIRONMENT
				vec3 indirectLight = mix(skyLightPhased, biomeIndirect, maxDistance);
				vec3 DirectLight = mix(stepLightSource, biomeDirect, maxDistance) * sh;
			#else
				vec3 indirectLight = skyLightPhased;
				vec3 DirectLight = stepLightSource * sh;
			#endif

			vec3 Lightning = Iris_Lightningflash_VLfog(progressP);
			vec3 lighting = DirectLight + indirectLight + 0.0025 * Lightning;
			
			color += (lighting - lighting * fogVolumeCoeff) * totalAbsorbance;

			// kill fog absorbance when in caves.
			totalAbsorbance *= mix(1.0, fogVolumeCoeff, lightLevelZero);
			if(totalAbsorbance < 0.01) break;

		//------------------------------------
		//------ ATMOSPHERE HAZE EFFECT
		//------------------------------------

			// maximum range for atmosphere haze, basically.
			float planetVolume = smoothstep(1.0 - exp(clamp(1.0 - length(progressP) / (16.0*150.0), 0.0,1.0) * -10.0), 0.0, progressP.y-500.0);

			// just air
			vec2 airCoef = exp2(-max(progressW.y-SEA_LEVEL,0.0)/vec2(8.0e3, 1.2e3)*vec2(6.0,7.0)) * 192.0 * Haze_amount * planetVolume;

			// Pbr for air, yolo mix between mie and rayleigh for water droplets
			vec3 rL = rC*airCoef.x;
			vec3 m =  mC*(airCoef.y+fogDensity*300.0);

			// calculate the atmosphere haze seperately and purely additive to color, do not contribute to absorbtion.
			vec3 atmosphereVolumeCoeff = exp(-(rL+m)*dd*dL);
			// vec3 Atmosphere = LightSourcePhased * sh * (rayL*rL + sunPhase*m) + AveragedAmbientColor * (rL+m);
			vec3 Atmosphere = (LightSourcePhased * sh * (rayL*rL + sunPhase*m) + AveragedAmbientColor * (rL+m) * (lightLevelZero*0.99 + 0.01)) * inACave;
			color += (Atmosphere - Atmosphere * atmosphereVolumeCoeff) / (rL+m+1e-6) * atmosphereAbsorbance;
	
			atmosphereAbsorbance *= atmosphereVolumeCoeff*fogVolumeCoeff;

			// totalAbsorbance *= dot(atmosphereVolumeCoeff,vec3(0.33333));
	}

	// sceneColor = finalsceneColor;

	// atmosphereAlpha = atmosphereAbsorbance;
	
	return vec4(color, totalAbsorbance);
}