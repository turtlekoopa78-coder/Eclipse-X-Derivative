### **TUTORIAL:**



* Extract the ECLIPSE X DERIVATIVE file.



* Move the Fusion Folder inside the main extracted zip to the downloads folder



* Move your Eclipse shader files to the Fusion Folder, Keep it Unzipped



* Then, click the path at the top and delete the text, then type "cmd"



* Copy the Paste the Command to the Terminal Below.



cd /d "%USERPROFILE%\\Downloads\\Fusion\\Eclipse-Derivative-Fusion-overlay" \&\& py apply\_fusion.py ..\\Eclipse-Shader-Unstable.zip



Requirements:



PYTHON 3.xx AND ABOVE

