EXTRACT THIS OVERLAY, DOWNLOAD ECLIPSE AND INSERT IT IN THE EXTRACTED FOLDER, THEN CLICK THE PATH AT THE TOP, UNTYPE THE PATH THEN TYPE cmd AFTER THAT COPY THESE COMMANDS



cd C:\\Users\\(your user)\\Downloads\\Fusion\\Eclipse-Derivative-Fusion-overlay



THEN AFTER PASTE THIS



"C:\\Users\\(your user)\\AppData\\Local\\Python\\pythoncore-3.14-64\\python.exe" apply\_fusion.py ..\\Eclipse-Shader-Unstable.zip



Requirements:



PYTHON 3.14 AND ABOVE



THATS IT





